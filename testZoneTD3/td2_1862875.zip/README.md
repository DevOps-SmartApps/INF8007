1862875 Corentin Bresteau

Programme TFIDF pour le cours INF8007 TD2.
Le calcul du TFIDF sans pickle est rapide mais demande beaucoup de mémoire pour gérer
une grosse matrice diagonale. Une fois le tfidf obtenu les calculs sont rapides.
Les dimensions de la réduction svd ne seront appliquées que si la matrice tfidf n'a pas
encore été calculée.
